class Usuario{

constructor(nome,idade,foto,latitude,longitude){

this.nome=nome
this.idade=idade
this.foto=foto
this.latitude=latitude
this.longitude=longitude

}

gerarCard(index){

return `
<div class="card">

<img src="${this.foto}">

<h3>${this.nome}</h3>

<p>${this.idade} anos</p>

<p>📍 ${this.latitude}</p>
<p>📍 ${this.longitude}</p>

<a href="https://www.google.com/maps?q=${this.latitude},${this.longitude}" target="_blank">
Ver no Maps
</a>

<br><br>

<button onclick="editarUsuario(${index})">Editar</button>
<button onclick="excluirUsuario(${index})">Excluir</button>

</div>
`

}

}

let usuarios=[]
let fotoAtual=""
let latitudeAtual=""
let longitudeAtual=""
let editandoId=null

function ativarCamera(){

navigator.mediaDevices.getUserMedia({video:true})

.then(stream=>{
document.getElementById("video").srcObject=stream
})

.catch(()=>{
alert("Permissão negada")
})

}

function capturarFoto(){

let video=document.getElementById("video")
let canvas=document.getElementById("canvas")
let ctx=canvas.getContext("2d")

canvas.width=video.videoWidth
canvas.height=video.videoHeight

ctx.drawImage(video,0,0)

fotoAtual=canvas.toDataURL("image/png")

document.getElementById("dragArea").innerHTML=`<img src="${fotoAtual}" width="100">`

}

function capturarLocalizacao(){

if(navigator.geolocation){

navigator.geolocation.getCurrentPosition(pos=>{

latitudeAtual=pos.coords.latitude.toFixed(6)
longitudeAtual=pos.coords.longitude.toFixed(6)

document.getElementById("statusLocalizacao").innerText="Localização capturada"

})

}

}

function cadastrar(){

let nome=document.getElementById("nome").value
let idade=document.getElementById("idade").value

if(!nome || !idade || !fotoAtual || !latitudeAtual){
alert("Preencha tudo")
return
}

if(editandoId!==null){

usuarios=usuarios.map((u,i)=>{

if(i===editandoId){

return new Usuario(nome,idade,fotoAtual,latitudeAtual,longitudeAtual)

}

return u

})

editandoId=null

}else{

let usuario=new Usuario(nome,idade,fotoAtual,latitudeAtual,longitudeAtual)

usuarios.push(usuario)

}

salvarStorage()

atualizarLista()

document.getElementById("nome").value=""
document.getElementById("idade").value=""

}

function excluirUsuario(index){

usuarios.splice(index,1)

salvarStorage()

atualizarLista()

}

function editarUsuario(index){

let usuario=usuarios[index]

document.getElementById("nome").value=usuario.nome
document.getElementById("idade").value=usuario.idade

fotoAtual=usuario.foto
latitudeAtual=usuario.latitude
longitudeAtual=usuario.longitude

editandoId=index

}

function ordenarIdade(){

usuarios.sort((a,b)=>a.idade-b.idade)

atualizarLista()

}

function buscarUsuario(){

let texto=document.getElementById("buscarNome").value.toLowerCase()

let resultado=usuarios.filter(u=>u.nome.toLowerCase().includes(texto))

renderizarLista(resultado)

}

document.getElementById("buscarNome").addEventListener("input",filtrarUsuarios)

function filtrarUsuarios(){

let texto=document.getElementById("buscarNome").value.toLowerCase()

let filtrados=usuarios.filter(u=>u.nome.toLowerCase().includes(texto))

renderizarLista(filtrados)

}

function atualizarLista(){

renderizarLista(usuarios)

document.getElementById("contadorUsuarios").innerText="Total de usuários: "+usuarios.length

}

function renderizarLista(lista){

let div=document.getElementById("listaUsuarios")

div.innerHTML=""

lista.forEach((u,index)=>{

div.innerHTML+=u.gerarCard(index)

})

}

function limparTodos(){

if(confirm("Deseja apagar todos?")){

usuarios=[]

localStorage.removeItem("usuarios")

atualizarLista()

}

}

function salvarStorage(){

localStorage.setItem("usuarios",JSON.stringify(usuarios))

}

window.onload=function(){

let dados=localStorage.getItem("usuarios")

if(dados){

let lista=JSON.parse(dados)

usuarios=lista.map(u=>new Usuario(u.nome,u.idade,u.foto,u.latitude,u.longitude))

atualizarLista()

}

carregarTema()

}

function alterarTema(){

document.body.classList.toggle("dark")

localStorage.setItem("tema",document.body.classList.contains("dark"))

}

function carregarTema(){

let tema=localStorage.getItem("tema")

if(tema==="true"){

document.body.classList.add("dark")

}

}