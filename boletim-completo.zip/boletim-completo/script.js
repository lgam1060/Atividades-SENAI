function calcularMedia() {

    // valores
    let nota1 = parseFloat(document.getElementById("nota1").value);
    let nota2 = parseFloat(document.getElementById("nota2").value);
    let nota3 = parseFloat(document.getElementById("nota3").value);

    // validação com o //
    if (
           isNaN(nota1) || isNaN(nota2) || isNaN(nota3) ||
        nota1 < 0 || nota1 > 10 ||
        nota2 < 0 || nota2 > 10 ||
        nota3 < 0 || nota3 > 10
    ) {
        document.getElementById("resultado").innerText = "Erro: Insira notas válidas entre 0 e 10.";
        return; // erro se estiver invalido
    }

    // Média
    
    
let media = (nota1 + nota2 + nota3) / 3;

    let situacao = "";

    // if else if
    if (media >= 9) {
        situacao = "Excelente";
    } 
else if (media >= 7) {
        situacao = "Aprovado";
    } 
    else if (media >= 5) {
        situacao = "Recuperação";
    } 
    else {
        situacao = "Reprovado";
    }

    // Mostrar resultado
document.getElementById("resultado").innerText =
        "Média: " + media.toFixed(2) + " - Situação: " + situacao;

    //parte extra,

    // Maior nota
let maior = Math.max(nota1, nota2, nota3);
    document.getElementById("maiorNota").innerText =
        "Maior nota: " + maior;

    // Menor nota
    let menor = Math.min(nota1, nota2, nota3);
    document.getElementById("menorNota").innerText =
        "Menor nota: " + menor;
    // Mensagem personalizada se média for 10
    if (media === 10) {
        document.getElementById("resultado").innerText +=
            " Parabens sua média foi perfeita";
    }
}
